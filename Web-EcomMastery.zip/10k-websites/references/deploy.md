# Publicación: Vercel con dominio de GoDaddy

El sitio vive en Vercel y la dirección es un dominio que el usuario compra en GoDaddy. Claude publica con la CLI de Vercel desde la carpeta del proyecto, un comando, y el usuario solo carga los registros DNS en GoDaddy una vez. El orden importa porque las etiquetas og necesitan la URL en vivo antes de publicar la versión final.

## La charla de costos honestos (dala durante la configuración, repítela antes de gastar; el punto del hosting espera a la Fase 10)

La charla de dinero ocurre ANTES de que se mueva el dinero, siempre:

- Una imagen de hero cuesta unos 2 créditos con los valores por defecto probados.
- Un video de hero cuesta aproximadamente entre 10 y 55 créditos según el modelo de video elegido; consulta el precio para tener los números exactos. El conector ofrece varios modelos de video, y ambos extremos de ese rango son de primer nivel de verdad al momento de escribir esto. La elección, y cómo presentarla con honestidad, está en la sección de consulta de costos de `prompt-laws.md`.
- El precio exacto de cada generación se puede consultar GRATIS antes de gastar con `get_cost: true`. Consulta todo: tomas individuales, imágenes de apoyo y cadenas completas; la comparación de modelos está en la sección de consulta de costos de `prompt-laws.md`. Presenta el total en palabras simples antes de generar.
- Empieza con la prueba gratis de Higgsfield. Alcanza para construir un primer sitio de recorrido único, re-intento incluido, y una primera construcción real se publicó solo con créditos de prueba. Un modelo de video más barato estira todavía más la prueba, de una sola toma a varias. Pasa a un plan pago cuando construyas más sitios o vayas más grande, y revisa los planes actuales en higgsfield.ai en lugar de confiar en un número escrito aquí. Dilo todo con claridad para que el usuario pueda planificar.
- El hosting y el dominio van aparte, y este es el punto que espera: pertenece a la Fase 10, en el momento en que el usuario dice que quiere el sitio online, nunca a la configuración. Dos costos, dichos con claridad:
  - **El dominio en GoDaddy:** un pago anual. El primer año suele tener precio promocional y la renovación sale más cara; que lo vea en el carrito antes de pagar. Solo el dominio: no hace falta ningún plan de hosting ni constructor de sitios de GoDaddy.
  - **Vercel:** el plan gratis (Hobby) sirve un sitio estático como este sin costo, pero está pensado para uso personal y no comercial. Si el sitio es de un negocio o de un cliente que paga, lo correcto es el plan Pro. Revisa el precio y las condiciones actuales en vercel.com/pricing en lugar de confiar en un número escrito aquí. Publicar y volver a publicar no cuesta nada.

## Paso 0: Conecta Vercel (solo en la primera publicación)

Vercel se conecta ahora, no durante la configuración, porque nada antes de este momento lo necesita. Si `npx vercel whoami` ya devuelve un usuario (sesión iniciada en un proyecto anterior, o antes en este), salta al Paso 1.

1. Ejecuta `npx vercel login` (en Windows, `npx.cmd vercel login`). No hace falta instalar nada: Node.js ya está desde la Fase 1. El navegador se abre en Vercel: el usuario crea una cuenta gratis o inicia sesión (con Google, GitHub o su correo) y confirma. Avísale que puede abrirse en un navegador distinto al que usa normalmente, y dale un check-in clicable (una opción, "Ya inicié sesión, revísalo") para hacer clic cuando lo haya hecho. Una llamada que queda esperando en este momento es el inicio de sesión en curso, no un cuelgue.
2. Si el navegador no se abre, la CLI muestra un link en la terminal: pásaselo al usuario para que lo abra él.
3. Confirma con `npx vercel whoami` que devuelve su usuario antes de publicar nada.

## Paso 1: Define la dirección, después actualiza las etiquetas og

Primero, ¿dónde va a vivir el sitio? Dos caminos, los dos reales:

- **El dominio de GoDaddy.** Si el usuario ya lo compró, usa ese. Escríbelo exactamente como él lo dio y confírmalo con una opción clicable antes de seguir: un error de una letra manda todo a un dominio ajeno.
- **La dirección gratis de Vercel** (`nombre-del-proyecto.vercel.app`). No es una opción menor: le permite ver el sitio en vivo hoy y conectar el dominio de GoDaddy después, sin rehacer nada.

Elige un nombre de proyecto en minúsculas con guiones a partir de la marca (por ejemplo `cafe-ember`); es lo que define la dirección `.vercel.app`.

Después actualiza las etiquetas. `og:image` y `og:url` necesitan URLs absolutas. Encuentra el comentario `<!-- DEPLOY STEP -->` que dejaste durante la construcción y actualiza ambas con la URL elegida: `https://dominio.com/` si va el dominio de GoDaddy, o la dirección `.vercel.app` si todavía no hay dominio (y vuelve a actualizarlas cuando se conecte el dominio). Haz esto ANTES de la publicación final, o la página publicada lleva etiquetas de vista previa muertas.

Actualiza con la herramienta de edición, nunca con un comando de una línea en la shell. Un buscar y reemplazar por script puede leer el archivo UTF-8 con la codificación por defecto equivocada y destrozar cada carácter especial de la página. La recuperación, si igual ocurre, está en `troubleshooting.md`.

## Paso 2: Prepara la carpeta de publicación

Vercel publica la carpeta tal cual, sin zip. El nivel superior de la carpeta que publicas tiene que ser el propio `index.html` con `assets/` al lado. Publica siempre desde DENTRO de esa carpeta, nunca desde la carpeta de arriba, o el sitio en vivo muestra un 404.

Si los crudos y las copias de revisión se guardaron fuera de la carpeta de publicación como se indicó, no hay nada que excluir. Si por algún motivo hay algo adentro que no debe publicarse, agrega un archivo `.vercelignore` con esas rutas (misma sintaxis que `.gitignore`). La carpeta `.vercel/` que crea la CLI guarda el vínculo con el proyecto; no se publica y no hay que borrarla.

## Paso 3: Publica en producción

Desde dentro de la carpeta de publicación:

```
npx vercel deploy --prod --yes --name nombre-del-proyecto
```

(En Windows, `npx.cmd`.) La primera vez crea el proyecto y lo vincula a la carpeta; las siguientes publicaciones solo necesitan `npx vercel deploy --prod --yes`. Al terminar devuelve la URL en vivo. Las subidas grandes están bien: un video de hero tarda unos segundos en subir. No es instantáneo, y eso es normal.

## Paso 4: Conecta el dominio de GoDaddy

Si el usuario eligió el camino de la dirección gratis, sáltate este paso por ahora; vuelve aquí cuando tenga el dominio.

1. **Agrega el dominio al proyecto**, desde la carpeta de publicación: `npx vercel domains add dominio.com`. Agrega también `www.dominio.com` para que las dos formas funcionen.
2. **Lee los registros exactos que pide Vercel:** `npx vercel domains inspect dominio.com`. Normalmente es un registro A para el dominio raíz con el valor `76.76.21.21` y un CNAME para `www` con el valor `cname.vercel-dns.com`, pero Vercel a veces da valores propios del proyecto. Usa SIEMPRE los que devuelve el inspect, nunca los de este archivo.
3. **Guía al usuario en GoDaddy, clic por clic.** Es el único paso manual de esta fase, y lo hace él porque es su cuenta. Dale los valores exactos en un bloque fácil de copiar y estos pasos:
   - Entrar a godaddy.com, iniciar sesión, ir a **Mis productos** (o **Cartera de dominios**) y hacer clic en el dominio.
   - Abrir **DNS** (Administrar DNS).
   - **Borrar** cualquier registro A del nombre `@` que apunte a otro lado, incluido el que dice **Parked** (estacionado). Si queda, el tráfico se divide entre GoDaddy y Vercel.
   - Agregar (o editar) un registro **A**: nombre `@`, valor el que dio Vercel. TTL por defecto.
   - En el registro **CNAME** de nombre `www`: cambiar su valor al que dio Vercel. Si no existe, agregarlo.
   - Guardar.
   - No tocar los servidores de nombres (nameservers) ni los registros MX: así el correo que tenga en GoDaddy sigue funcionando.
   Luego espera con un check-in clicable: una opción, "Listo, lo cargué".
4. **Verifica tú mismo.** Corre `npx vercel domains inspect dominio.com` hasta que Vercel muestre la configuración como válida. La propagación suele tardar minutos, a veces más: díselo al usuario en una línea, y vuelve a revisar en intervalos en lugar de declararlo roto. Si después de un buen rato sigue inválido, revisa con él la pantalla de DNS de GoDaddy: casi siempre es el registro Parked que quedó, o un valor mal pegado.

**El candado HTTPS llega solo.** Vercel emite el certificado automáticamente cuando el DNS ya apunta bien. Si el navegador muestra una advertencia de seguridad justo después de conectar el dominio, es el certificado todavía emitiéndose, no un sitio roto. Díselo al usuario con claridad, espera unos minutos y vuelve a revisar antes de declarar el sitio terminado. La dirección `.vercel.app` viene con el candado ya funcionando.

## Paso 5: Verifica tú mismo el sitio en vivo (antes de decirle al usuario que está listo)

- La página carga por HTTPS con un 200, en el dominio y en `www`.
- La URL del video en sí responde (pídela directamente).
- La consola del navegador está limpia en la URL en vivo.
- Recorre el hero con el scroll en el sitio en vivo: la descarga como Blob hace que los saltos funcionen en cualquier host, pero confírmalo.

## Paso 6: Las pruebas de velocidad (mide, después presenta)

Justo después de la verificación en vivo, mide el sitio en vivo y anota los números. Son la prueba de que el sitio es rápido, y el usuario los va a necesitar. Mide en la URL en vivo:

- **El peso total de la página sin contar el video.** Una construcción sana queda en las decenas de KB.
- **El tiempo de carga de la página.** Una construcción sana carga en bastante menos de un segundo.
- **El tamaño del video y su tiempo de llegada detrás del anillo de carga.** Una sola toma llega en unos segundos con una conexión normal; un recorrido encadenado tarda más. Todo eso mientras la página ya es completamente usable.

**Cómo medir, concretamente.** Dos opciones listas para usar:

- Tiempos con curl en la URL en vivo: `curl -s -o /dev/null -w "TTFB %{time_starttransfer}s, total %{time_total}s, %{size_download} bytes\n" https://the-live-url/` (en Windows llama a `curl.exe`, y `-o NUL` también funciona). Córrelo contra la página y contra la URL del video para obtener los tamaños y los tiempos.
- O abre la URL en vivo con la herramienta de navegador y lee los tiempos de navegación: `performance.getEntriesByType('navigation')[0].loadEventEnd` para el tiempo de carga, y `performance.getEntriesByType('resource')` para el `transferSize` de cada archivo.

Solo mediciones reales. Nunca presentes una estimación como prueba.

Presenta los números al usuario junto con el argumento estructural, porque juntos responden la objeción número uno a los sitios cinematográficos ("bonito, pero seguro lento, seguro con un mal backend"): estos sitios son archivos estáticos simples, servidos desde la red global de Vercel. Sin framework, sin paso de compilación, sin código de servidor, así que no hay backend que pueda ser malo. El video llega en streaming detrás de un póster y un anillo de progreso honesto, y las pantallas chicas nunca descargan la versión pesada. Anota los números para que el usuario pueda citárselos a su propio cliente.

## Paso 7: La prueba del usuario en su dispositivo real

Dale al usuario el link en vivo y haz que pruebe el sitio en computadora Y en su teléfono, con la red real, no solo en localhost. Pídele que revise específicamente el scroll en la parte superior e inferior del hero, en Chrome, donde los tirones se notan primero. Sus ojos y su hardware detectan lo que las auditorías no pueden.

## Paso 8: Iterar es barato

Cambia los archivos y vuelve a publicar con `npx vercel deploy --prod --yes` desde la carpeta de publicación. Un comando, y el dominio de GoDaddy sigue apuntando solo a la versión nueva: no hay que volver a tocar el DNS. No le temas a las rondas de pulido; el ciclo no cuesta nada más que un minuto. Vuelve a verificar la página en vivo después de cada publicación (una caché vieja puede mostrar la versión anterior; recarga forzada o revisa un texto que sepas que cambió).
